# lambda arguments:expression

def square(x): return x * x

square_lambda = lambda x: x * x

print(square(5))